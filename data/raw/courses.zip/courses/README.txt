Most of the contents of this directory are directories with numeric names, representing all available disciplines.

38                               <--- discipline #38
├── bachelor                     
│   ├── 38-bachelor-1000.json    <--- the first 1000 BACHELOR courses for discipline #38
│   └── 38-bachelor-2000.json 	 <--- up to the next 1000 BACHELOR courses for discipline #38
├── master                       
│   ├── 38-master-1000.json 	 <--- the first	1000 MASTER courses for discipline #38
│   └── 38-master-2000.json      <--- up to the next 1000 MASTER courses for discipline #38
├── phd                          
│   └── 38-phd-1000.json         <--- up to the first 1000 PHD courses for discipline #38
├── preparation			 
│   └── 38-preparation-1000.json <--- up to the first 1000 PREPARATION courses for discipline #38
└── short                        
    └── 38-short-1000.json       <--- up to the first 1000 SHORT courses for discipline #38


Important/interesting notes:
1) Courses can have multiple disciplines. The average number of disciplines per course is 1.79.
2) There are over 170k courses, and over 200 disciplines.
3) The same discipline ontology is used for all course levels (Bachelor, PhD, etc)
4) The discipline ontology is nested at 2 levels.

There are three metadata files to help you navigate the data:

1) discipline_dictionary.json: Metadata for disciplines, including disclipline name and parent name
2) course_discipline_lookup.json: Look-up table of course_id --> [discipline ids]
3) discipline_course_lookup.json: Look-up table of discipline_id --> [course ids]
